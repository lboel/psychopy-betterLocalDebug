from flask import Flask
app = Flask(__name__)
import psychopy_betterLocalDebug.views